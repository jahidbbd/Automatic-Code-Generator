﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class InternelMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                lblCopyright.Text = ConfigurationManager.AppSettings.Get("copyright").ToString();
                lnkFb.NavigateUrl = ConfigurationManager.AppSettings.Get("fblink").ToString();
                lnkTwitter.NavigateUrl = ConfigurationManager.AppSettings.Get("twitterlink").ToString();


                lblDateTime.Text = DateTime.Now.ToString("dd MMMM, yyyy hh:mm tt");
                lblIP.Text = getIP().ToString();
                
                //TextBox Password = new TextBox();
                //Login LoginMain = LoginViewMain.FindControl("LoginMain") as Login;
                //if (LoginMain != null)
                //    Password = LoginMain.FindControl("Password") as TextBox;
                //if (Password != null)
                //    Password.Attributes.Add("Value", "Password");
            }
        }
        catch(Exception Ex)
        {
            Utilities.LogError(Ex);
        }
    }

    //IP Address
    private string getIP()
    {
        try
        {
            string ip = "";
            string forwarder = "";
            forwarder = Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (!string.IsNullOrEmpty(forwarder))
            {
                string[] ipRange = forwarder.Split(',');
                int le = ipRange.Length - 1;
                ip = ipRange[le];
            }
            else
            {
                ip = Request.ServerVariables["REMOTE_ADDR"];
            }
            return ip;
        }
        catch(Exception Ex)
        {
            
              return "";
        }
    }
}
