﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for NewsProvider
/// </summary>

    public class ArticleProvider:CommonEntityProvider
    {
        public ArticleProvider()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // Used to save news
        public int save(Article o)
        {
            try
            {
                SqlCommand inscmd = new SqlCommand("[dbo].[Proc_InsertUpdate_Article]", DBCon.Connection);
                inscmd.CommandType = CommandType.StoredProcedure;
                inscmd.Parameters.Add("@ID", SqlDbType.Int).Value =o.ID;
                inscmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                inscmd.Parameters.Add("@Name", SqlDbType.NVarChar, 50).Value = o.Name;
                inscmd.Parameters.Add("@Details", SqlDbType.NText).Value = o.Details;                                         
                inscmd.Parameters.Add("@ActiveStatus", SqlDbType.Char, 1).Value = o.ActiveStatus;                
                inscmd.Parameters.Add("@User", SqlDbType.VarChar, 50).Value = o.InsertedBy;


                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                inscmd.ExecuteNonQuery();
                if (DBCon.Connection.State == ConnectionState.Open)
                    DBCon.Connection.Close();

                int id = (int)inscmd.Parameters["@ID"].Value;
                return id;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
        }

        //This procedure is used to retrieve data by searching in the article table
        public IDataReader Search(string query)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("[Proc_Search_Article]", DBCon.Connection);
                cmd.CommandType = CommandType.StoredProcedure;
                
                cmd.Parameters.Add("@Query", SqlDbType.VarChar, 100).Value = query;
               

                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                return reader;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
        }

     }

