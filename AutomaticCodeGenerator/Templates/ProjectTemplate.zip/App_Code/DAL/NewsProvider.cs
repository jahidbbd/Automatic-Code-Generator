﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for NewsProvider
/// </summary>

    public class NewsProvider:CommonEntityProvider
    {
        public NewsProvider()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // Used to save news
        public int save(News o)
        {
            try
            {
                SqlCommand inscmd = new SqlCommand("[dbo].[Proc_InsertUpdate_News]", DBCon.Connection);
                inscmd.CommandType = CommandType.StoredProcedure;
                inscmd.Parameters.Add("@ID", SqlDbType.Int).Value =o.ID;
                inscmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                inscmd.Parameters.Add("@NewsTitle", SqlDbType.VarChar,250).Value = o.Name;              
                inscmd.Parameters.Add("@Description", SqlDbType.NText).Value = o.Description;
                inscmd.Parameters.Add("@Date", SqlDbType.DateTime).Value = o.Date;
                inscmd.Parameters.Add("@ActiveStatus", SqlDbType.Char, 1).Value = o.ActiveStatus;                
                inscmd.Parameters.Add("@User", SqlDbType.VarChar, 50).Value = o.InsertedBy;


                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                inscmd.ExecuteNonQuery();
                if (DBCon.Connection.State == ConnectionState.Open)
                    DBCon.Connection.Close();

                int id = (int)inscmd.Parameters["@ID"].Value;
                return id;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
        }

     }

