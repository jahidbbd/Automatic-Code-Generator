﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for SQLCommonEntityProvider
/// </summary>
/// 


    public class CommonEntityProvider
    {
        protected DBConnection DBCon = new DBConnection();
	    
        public CommonEntityProvider()
	    {
		    //
		    // TODO: Add constructor logic here
		    //
	    }

        public int save(string procName, CommonEntity ce)
        {
            try
            {
                SqlCommand inscmd = new SqlCommand(procName, DBCon.Connection);
                inscmd.CommandType = CommandType.StoredProcedure;
                inscmd.Parameters.Add("@ID", SqlDbType.Int).Value = ce.ID;
                inscmd.Parameters["@ID"].Direction = ParameterDirection.InputOutput;
                inscmd.Parameters.Add("@Name", SqlDbType.VarChar, 50).Value = ce.Name;
                inscmd.Parameters.Add("@ActiveStatus", SqlDbType.Char, 1).Value = ce.ActiveStatus;
                inscmd.Parameters.Add("@User", SqlDbType.VarChar, 50).Value = ce.InsertedBy;

                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                inscmd.ExecuteNonQuery();                
                int id = (int)inscmd.Parameters["@ID"].Value;
                DBCon.Connection.Close();
                return id;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
        }


        //To delete data from the database
        public int delete(CommonEntity o, string procName)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(procName, DBCon.Connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = o.ID;

                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                cmd.ExecuteNonQuery();
                if (DBCon.Connection.State == ConnectionState.Open)
                    DBCon.Connection.Close();

                int id = (int)cmd.Parameters["@ID"].Value;
                return id;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
        }



        //To delete data from the database
        public int delete(int o, string procName)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(procName, DBCon.Connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = o;

                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                cmd.ExecuteNonQuery();
                if (DBCon.Connection.State == ConnectionState.Open)
                    DBCon.Connection.Close();

                int id = (int)cmd.Parameters["@ID"].Value;
                return id;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return 0;
            }
        }


        //To retrieve data from the database
        public IDataReader retrieve(string procName)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(procName, DBCon.Connection);
                cmd.CommandType = CommandType.StoredProcedure;
                
                DBCon.Connection.Open();
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                return reader;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
        }


        //This procedure is used to retrieve data taking the id and status parameters
        public IDataReader retrieve(string procName, int id, char activeStatus)
        {
            try
            
            {
                SqlCommand cmd = new SqlCommand(procName, DBCon.Connection);
                cmd.CommandType = CommandType.StoredProcedure;
                if (id != 0)
                {
                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                }
                if (activeStatus != 'N')
                {
                    cmd.Parameters.Add("@ActiveStatus", SqlDbType.Char, 1).Value = activeStatus;
                }
                
                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);
               
                return reader;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
        }


        //This procedure is used to retrieve data taking the id, status and a foreign key parameters
        public IDataReader retrieve(string procName, int id, char status, int fid)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(procName, DBCon.Connection);
                cmd.CommandType = CommandType.StoredProcedure;
                if (id != 0)
                {
                    cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                }
                if (status != 'N')
                {
                    cmd.Parameters.Add("@ActiveStatus", SqlDbType.Char, 1).Value = status;
                }
                if (fid != 0)
                {
                    cmd.Parameters.Add("@FID", SqlDbType.Int).Value = fid;
                }
                
                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                return reader;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
        }


        //This procedure is used to retrieve data taking the BrandShopID, and UserName
        public IDataReader retrieve(string procName, int BrandShopID, string UserName)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(procName, DBCon.Connection);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@BrandShopID", SqlDbType.Int).Value = BrandShopID;
                cmd.Parameters.Add("@UserName", SqlDbType.VarChar, 50).Value = UserName;
               
                if (DBCon.Connection.State != ConnectionState.Open)
                    DBCon.Connection.Open();
                IDataReader reader = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                return reader;
            }
            catch (SqlException sqlEx)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError(sqlEx.Number.ToString(), sqlEx.Message.ToString(), sqlEx.Source.ToString(), sqlEx.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());

                if (DBCon.Connection.State != ConnectionState.Closed)
                {
                    DBCon.Connection.Close();
                }
                return null;
            }
        }
    }

