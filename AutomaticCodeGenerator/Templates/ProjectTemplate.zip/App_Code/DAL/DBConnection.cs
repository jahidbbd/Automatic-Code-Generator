﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Configuration;

    /******************************************************************************************************
     * This class is used for database connection settings
     * By: Abdullah Al-Muzahid
     * Date: 14th March 2010
     * 
     * ****************************************************************************************************/


    public class DBConnection
    {
        //private static string serverName;
        //private static string databaseName;
        //private static string userID;
        //private static string password;

        private static SqlConnection SQLConn;


        public DBConnection()
        {           
                //Taking the connection string from the config file
            SQLConn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        }
        //public string Server
        //{
        //    get 
        //    {
        //        return serverName;
        //    }
        //    set
        //    {
        //        serverName = value;
        //    }
        //}

        //public string Database
        //{
        //    get
        //    {
        //        return databaseName;
        //    }
        //    set
        //    {
        //        databaseName = value;
        //    }
        //}

        //public string User
        //{
        //    get
        //    {
        //        return userID;
        //    }
        //    set
        //    {
        //        userID = value;
        //    }
        //}

        //public string Password
        //{
        //    get
        //    {
        //        return password;
        //    }
        //    set
        //    {
        //        password = value;
        //    }
        //}

        public SqlConnection Connection
        {
            get
            {
                return SQLConn;
            }
            set
            {
                SQLConn = value;
            }
        }

    }




