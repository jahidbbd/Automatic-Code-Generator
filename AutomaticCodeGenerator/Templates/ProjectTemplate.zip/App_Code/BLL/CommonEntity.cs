﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;


/************************************************************************************
 * CommonEntity Class
 * Developed By: Abdullah Al-Muzahid
 * Date: 10th March 2010
 * Description: This class is used to simulate diffent types of lookup entities with two 
 * general properties like ID and Name, specially all lookup entity
 * related database transactions are done using this class
 * **********************************************************************************/
 

    public class CommonEntity : Entity
    {
        protected int id;
        protected string name;
        protected char activeStatus;
        protected string insertedBy, updatedBy;
        protected DateTime insertedOn, updatedOn; 

        public CommonEntity()
        {
            id = 0;
            name = "";
            activeStatus = 'A';
            insertedBy = "";
            updatedBy = "";
            insertedOn = DateTime.Now;
            updatedOn = DateTime.Now;

        }

        public CommonEntity(int id, string name, char activestatus, string insertedBy, DateTime insertedOn)
        {
            this.id = id;
            this.name = name;
            this.activeStatus = activestatus;
            this.insertedBy = insertedBy;
            insertedOn = insertedOn;                
        } 

        #region Properties

        public override int ID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }
        public override string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public override char ActiveStatus
        {
            get
            {
                return activeStatus;
            }
            set
            {
                activeStatus = value;
            }
        }

        public override string InsertedBy
        {
            get
            {
                return insertedBy;
            }
            set
            {
                insertedBy = value;
            }
        }

        public override DateTime InsertedOn
        {
            get
            {
                return insertedOn;
            }
            set
            {
                insertedOn = value;
            }
        }

        public override string UpdatedBy
        {
            get
            {
                return updatedBy;
            }
            set
            {
                updatedBy = value;
            }
        }

        public override DateTime UpdatedOn
        {
            get
            {
                return updatedOn;
            }
            set
            {
                updatedOn = value;
            }
        }
        #endregion

    }
