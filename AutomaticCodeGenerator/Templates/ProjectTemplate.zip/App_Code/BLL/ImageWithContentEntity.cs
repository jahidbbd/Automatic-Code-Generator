﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


    public class ImageWithContentEntity : ContentEntity
    {
        protected string photoURL;

        public ImageWithContentEntity()
        {
            photoURL="";
        }


        public ImageWithContentEntity(int id, string name, string photoURL, string description, char activestatus, string insertedBy, string updatedBy)
        {
            this.id = id;
            this.name = name;
            this.photoURL = photoURL;
            this.description = description;            
            this.activeStatus = activestatus;
            this.insertedBy = insertedBy;
            this.updatedBy = updatedBy;
            this.insertedOn = DateTime.Now;
            this.updatedOn = DateTime.Now;
        }
        
        public string PhotoURL
        {
            get
            {
                return photoURL;
            }
            set
            {
                photoURL = value;
            }
        }

    }




