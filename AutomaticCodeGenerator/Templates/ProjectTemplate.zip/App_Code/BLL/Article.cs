﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/************************************************************************************
 * Class : Article
 * Developed By: Dipankar Basu
 * Date: 07 January, 2012
 * Description: This class is used to simulate Section, specially all 
 * Section related database transactions are done using this class
 * **********************************************************************************/

    public class Article: CommonEntity
    {        
        private string details, articlename;      

        public Article()
        {         
            details = "";
           
        }


        public Article(int id, string name, string details, char activestatus, string insertedBy, DateTime insertedOn)
        {
            this.id = id;
            this.name = name;
            this.details = details;            
            this.activeStatus = activestatus;
            this.insertedBy = insertedBy;
            this.updatedBy = updatedBy;
            insertedOn = DateTime.Now;
            updatedOn = DateTime.Now;
        }

        #region Properties

        public string Details
        {
            get
            {
                return details;
            }
            set
            {
                details = value;
            }
        }

       
        #endregion

    }

