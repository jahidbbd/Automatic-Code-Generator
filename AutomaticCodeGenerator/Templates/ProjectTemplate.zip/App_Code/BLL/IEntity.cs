﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;


/************************************************************************************
 * IEntity Interface
 * Developed By: Abdullah Al-Muzahid
 * Date: 10th March 2010
 * Description: This is the root level interface class
 * **********************************************************************************/

   
    public interface IEntity
    {
        int ID
        {
            get;
            set;
        }  
        string Name
        {
            get;
            set;
        }

        char ActiveStatus
        {
            get;
            set;
        }

        string InsertedBy
        {
            get;
            set;
        }

        DateTime InsertedOn
        {
            get;
            set;
        }

        string UpdatedBy
        {
            get;
            set;
        }

        DateTime UpdatedOn
        {
            get;
            set;
        }
    }

