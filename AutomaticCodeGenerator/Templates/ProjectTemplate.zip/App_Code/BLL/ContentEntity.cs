﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


    public class ContentEntity : CommonEntity
    {
        protected string description;

        public ContentEntity()
        {
            description = "";
        }


        public ContentEntity(int id, string name, string description, char activestatus, string insertedBy, DateTime insertedOn)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.activeStatus = activestatus;
            this.insertedBy = insertedBy;
            this.insertedOn = insertedOn;
           
        }

        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }

    }




