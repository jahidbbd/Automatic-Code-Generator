﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for AboutUsManager
/// </summary>

    public class ContentEntityManager
    {
        public ContentEntityManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // Save AboutUs
        public static int save(string procName, ContentEntity o)
        {
            try
            {
                ContentEntityProvider np = new ContentEntityProvider();
                int id = np.save(procName, o);
                return id;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
                return 0;
            }
        }


        public static ContentEntity GetFromReader(IDataReader reader)
        {
            try
            {
                ContentEntity o = new ContentEntity
                    (
                        (int)reader["ID"],
                        reader["Name"].ToString(),
                        reader["Description"].ToString(),
                        Convert.ToChar(reader["ActiveStatus"].ToString()),
                        reader["InsertedBy"].ToString(),
                        Convert.ToDateTime(reader["InsertedOn"].ToString())
                    );
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }


        public static ContentEntity retrieve(string procName, int id)
        {
            try
            {
                ContentEntity o = new ContentEntity();
                ContentEntityProvider np = new ContentEntityProvider();
                IDataReader reader = np.retrieve(procName, id, 'N');
                while (reader.Read())
                {
                    o = GetFromReader(reader);
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }

        public static List<ContentEntity> retrieve(string procName, int id, char status)
        {
            try
            {
                List<ContentEntity> o = new List<ContentEntity>();
                ContentEntityProvider np = new ContentEntityProvider();
                IDataReader reader = np.retrieve(procName, id, status);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }        

    }


