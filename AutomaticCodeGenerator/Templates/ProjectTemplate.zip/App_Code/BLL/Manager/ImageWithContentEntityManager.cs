﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for AboutUsManager
/// </summary>

    public class ImageWithContentEntityManager
    {
        public ImageWithContentEntityManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // Save AboutUs
        public static int save(string procName, ImageWithContentEntity o)
        {
            try
            {
                ImageWithContentEntityProvider np = new ImageWithContentEntityProvider();
                int id = np.save(procName, o);
                return id;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
                return 0;
            }
        }


        public static ImageWithContentEntity GetFromReader(IDataReader reader)
        {
            try
            {
                ImageWithContentEntity o = new ImageWithContentEntity
                    (
                        (int)reader["ID"],
                        reader["Name"].ToString(),                        
                        reader["PhotoURL"].ToString(),
                        reader["Description"].ToString(),
                        Convert.ToChar(reader["ActiveStatus"].ToString()),
                        "",
                        ""
                    );
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }


        public static ImageWithContentEntity retrieve(string procName, int id)
        {
            try
            {
                ImageWithContentEntity o = new ImageWithContentEntity();
                ImageWithContentEntityProvider np = new ImageWithContentEntityProvider();
                IDataReader reader = np.retrieve(procName, id, 'N');
                while (reader.Read())
                {
                    o = GetFromReader(reader);
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }

        public static List<ImageWithContentEntity> retrieve(string procName, int id, char status)
        {
            try
            {
                List<ImageWithContentEntity> o = new List<ImageWithContentEntity>();
                ImageWithContentEntityProvider np = new ImageWithContentEntityProvider();
                IDataReader reader = np.retrieve(procName, id, status);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }        

    }


