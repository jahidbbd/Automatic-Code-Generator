﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for CommonEntityManager
/// </summary>
/// 

    public class CommonEntityManager
    {
        public CommonEntityManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public static int save(string procName, CommonEntity o)
        {
            try
            {
                CommonEntityProvider ep = new CommonEntityProvider();
                int id = ep.save(procName, o);
                return id;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
                return 0;
            }
        }

        // Delete using ID ***********
        public static void delete(CommonEntity o, string procName)
        {
            try
            {
                CommonEntityProvider ep = new CommonEntityProvider();
                int id = ep.delete(o, procName);
                //return id;

            }
            catch (Exception Ex)
            {
                ErrorManager errl = new ErrorManager();
                errl.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());
            }
        }

        // Delete using ID ***********
        public static void delete(int o, string procName)
        {
            try
            {
                CommonEntityProvider ep = new CommonEntityProvider();
                int id = ep.delete(o, procName);
                //return id;

            }
            catch (Exception Ex)
            {
                ErrorManager errl = new ErrorManager();
                errl.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());
            }
        }

        public static CommonEntity GetFromReader(IDataReader reader)
        {
            try
            {
                CommonEntity o = new CommonEntity
                    (
                        (int)reader["ID"],
                        reader["Name"].ToString(),
                        Convert.ToChar(reader["ActiveStatus"].ToString()),
                        reader["InsertedBy"].ToString(),
                        Convert.ToDateTime(reader["InsertedOn"].ToString())
                    );
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }

        public static List<CommonEntity> retrieve(string procName)
        {
            try
            {
                List<CommonEntity> o = new List<CommonEntity>();
                CommonEntityProvider ep = new CommonEntityProvider();
                IDataReader reader = ep.retrieve(procName);
                while (reader.Read())
                {
                     o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }

        public static CommonEntity retrieve(string procName, int id)
        {
            try
            {
                CommonEntity o = new CommonEntity();
                CommonEntityProvider ep = new CommonEntityProvider();
                IDataReader reader = ep.retrieve(procName, id, 'N');
                while (reader.Read())
                {
                    o=GetFromReader(reader);
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
           
                return null;
            }
        }

        public static List<CommonEntity> retrieve(string procName, int id, char status)
        {
            try
            {
                List<CommonEntity> o = new List<CommonEntity>();
                CommonEntityProvider ep = new CommonEntityProvider();
                IDataReader reader = ep.retrieve(procName, id, status);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
           
                return null;
            }
        }


        public static List<CommonEntity> retrieve(string procName, int id, char status, int fid)
        {
            try
            {
                List<CommonEntity> o = new List<CommonEntity>();
                CommonEntityProvider ep = new CommonEntityProvider();
                IDataReader reader = ep.retrieve(procName, id, status, fid);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
           
                return null;
            }
        }

        // Retrieve Like Status of a BrandShop using BrandShopID and UserName
        public static List<CommonEntity> retrieve(string procName, int BrandShopID, string UserName)
        {
            try
            {
                List<CommonEntity> o = new List<CommonEntity>();
                CommonEntityProvider ep = new CommonEntityProvider();
                IDataReader reader = ep.retrieve(procName, BrandShopID, UserName);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }

    }

