﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for NewsManager
/// </summary>

    public class NewsManager
    {
        public NewsManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // Save News
        public static int save(News o)
        {
            try
            {
                NewsProvider np = new NewsProvider();
                int id = np.save(o);
                return id;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());
                return 0;
            }
        }      


        public static News GetFromReader(IDataReader reader)
        {
            try
            {
                News o = new News
                    (
                        (int)reader["ID"],
                        reader["Name"].ToString(),                        
                        reader["Description"].ToString(),
                        Convert.ToDateTime(reader["Date"].ToString()),
                        Convert.ToChar(reader["ActiveStatus"].ToString()),                        
                        "",
                        ""
                    );
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }


        public static List<News> retrieve(string procName)
        {
            try
            {
                List<News> o = new List<News>();
                NewsProvider np = new NewsProvider();
                IDataReader reader = np.retrieve(procName);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }


        public static News retrieve(string procName, int id)
        {
            try
            {
                News o = new News();
                NewsProvider np = new NewsProvider();
                IDataReader reader = np.retrieve(procName, id, 'N');
                while (reader.Read())
                {
                    o = GetFromReader(reader);
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }

        public static List<News> retrieve(string procName, int id, char status)
        {
            try
            {
                List<News> o = new List<News>();
                NewsProvider np = new NewsProvider();
                IDataReader reader = np.retrieve(procName, id, status);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", ex.Message.ToString(), ex.Source.ToString(), ex.StackTrace.ToString());

                return null;
            }
        }

    }

