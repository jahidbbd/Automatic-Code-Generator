﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for NewsManager
/// </summary>

    public class ArticleManager
    {
        public ArticleManager()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // Save News
        public static int save(Article o)
        {
            try
            {
                ArticleProvider np = new ArticleProvider();
                int id = np.save(o);
                return id;
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                return 0;
            }
        }


        public static Article GetFromReader(IDataReader reader)
        {
            try
            {
                Article o = new Article
                    (
                        (int)reader["ID"],
                        reader["Name"].ToString(),
                        reader["Details"].ToString(),                                 
                        Convert.ToChar(reader["ActiveStatus"].ToString()),  
                        reader["InsertedBy"].ToString(),
                        Convert.ToDateTime(reader["InsertedOn"].ToString())                        
                    );
                
                return o;
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                return null;
            }
        }


        public static List<Article> retrieve(string procName)
        {
            try
            {
                List<Article> o = new List<Article>();
                ArticleProvider np = new ArticleProvider();
                IDataReader reader = np.retrieve(procName);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                return null;
            }
        }

        public static Article retrieve(string procName, int id)
        {
            try
            {
                Article o = new Article();
                ArticleProvider np = new ArticleProvider();
                IDataReader reader = np.retrieve(procName, id, 'N');
                while (reader.Read())
                {
                    o = GetFromReader(reader);
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                return null;
            }
        }

        public static List<Article> retrieve(string procName, int id, char status)
        {
            try
            {
                List<Article> o = new List<Article>();
                ArticleProvider np = new ArticleProvider();
                IDataReader reader = np.retrieve(procName, id, status);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();
                
                return o;
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                return null;
            }
        }

        public static List<Article> Search(string query)
        {
            try
            {
                List<Article> o = new List<Article>();
                ArticleProvider np = new ArticleProvider();
                IDataReader reader = np.Search(query);
                while (reader.Read())
                {
                    o.Add(GetFromReader(reader));
                }
                reader.Close();
                reader.Dispose();

                return o;
            }
            catch (Exception ex)
            {
                Utilities.LogError(ex);
                return null;
            }
        }
    }

