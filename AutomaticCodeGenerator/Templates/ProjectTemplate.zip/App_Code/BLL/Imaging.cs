﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

/************************************************************************************
 * Imaging Class
 * Developed By: Abdullah Al-Muzahid
 * Date: 10th March 2010
 * Description: This class is used to do any kind of image related activities
 * **********************************************************************************/

    public class Imaging
    {
        //Used to save jpeg image
        public static void saveJpeg(string path, System.Drawing.Image img, long quality)
        {
            try
            {
                // Encoder parameter for image quality
                System.Drawing.Imaging.EncoderParameter qualityParam = new System.Drawing.Imaging.EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);

                // Jpeg image codec
                System.Drawing.Imaging.ImageCodecInfo jpegCodec = getEncoderInfo("image/jpeg");

                if (jpegCodec == null)
                    return;

                System.Drawing.Imaging.EncoderParameters encoderParams = new System.Drawing.Imaging.EncoderParameters(1);
                encoderParams.Param[0] = qualityParam;

                img.Save(path, jpegCodec, encoderParams);
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());
            }
        }

        //To get encoder info
        public static System.Drawing.Imaging.ImageCodecInfo getEncoderInfo(string mimeType)
        {
            try
            {
                // Get image codecs for all image formats
                System.Drawing.Imaging.ImageCodecInfo[] codecs = System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders();

                // Find the correct image codec
                for (int i = 0; i < codecs.Length; i++)
                    if (codecs[i].MimeType == mimeType)
                        return codecs[i];
                return null;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());
                return null;
            }
        }

        //Used to resize the image
        public static System.Drawing.Image resizeImage(System.Drawing.Image imgToResize, System.Drawing.Size size)
        {
            int sourceWidth = imgToResize.Width;
            int sourceHeight = imgToResize.Height;

            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;
            try
            {

                nPercentW = ((float)size.Width / (float)sourceWidth);
                nPercentH = ((float)size.Height / (float)sourceHeight);

                if (nPercentH < nPercentW)
                    nPercent = nPercentH;
                else
                    nPercent = nPercentW;

                int destWidth = (int)(sourceWidth * nPercent);
                int destHeight = (int)(sourceHeight * nPercent);

                System.Drawing.Bitmap b = new System.Drawing.Bitmap(destWidth, destHeight);
                System.Drawing.Graphics g = System.Drawing.Graphics.FromImage((System.Drawing.Image)b);
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
                g.Dispose();

                //return b;
                return (System.Drawing.Image)b;
            }
            catch (Exception Ex)
            {
                ErrorManager errL = new ErrorManager();
                errL.WriteError("", Ex.Message.ToString(), Ex.Source.ToString(), Ex.StackTrace.ToString());
                return null;
            }

        }
    }


