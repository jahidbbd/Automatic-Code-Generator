﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;


/************************************************************************************
 * Entity Abstract Class
 * Developed By: Abdullah Al-Muzahid
 * Date: 10th March 2010
 * Description: This is the root level abstract class
 * **********************************************************************************/

    public abstract class Entity : IEntity
    {
        //protected DBConnection DBCon;

        public Entity()
        {
            //DBCon = new DBConnection();
        }

        public abstract int ID
        {
            get;
            set;
        }
        public abstract string Name
        {
            get;
            set;
        }

        public abstract char ActiveStatus
        {
            get;
            set;
        }

        public abstract string InsertedBy
        {
            get;
            set;
        }

        public abstract DateTime InsertedOn
        {
            get;
            set;
        }

        public abstract string UpdatedBy
        {
            get;
            set;
        }

        public abstract DateTime UpdatedOn
        {
            get;
            set;
        }
    }

