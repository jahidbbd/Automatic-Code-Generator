﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/************************************************************************************
 * Class : News
 * Developed By: Dipankar Basu
 * Date: 08 October, 2011
 * Description: This class is used to simulate News and AboutUs, specially all 
 * News and AboutUs related database transactions are done using this class
 * **********************************************************************************/

    public class News: CommonEntity
    {        
        private string description;
        private DateTime date;

        public News()
        {         
            description = "";
            date = DateTime.Now;
        }


        public News(int id, string name, string description, DateTime date, char activestatus, string insertedBy, string updatedBy)
        {
            this.id = id;
            this.name = name;
            this.description = description;
            this.date = date;
            this.activeStatus = activestatus;
            this.insertedBy = insertedBy;
            this.updatedBy = updatedBy;
            insertedOn = DateTime.Now;
            updatedOn = DateTime.Now;     
        }


        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }

        public DateTime Date
        {
            get
            {
                return date;
            }
            set
            {
                date = value;
            }
        }
    }

